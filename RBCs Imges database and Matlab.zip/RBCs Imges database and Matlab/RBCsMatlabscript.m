clear; clc; % clf;
%imageno=input('Inter the image number  ');
for xx= 1   %xx is the no. of images
    
name = ['A (',int2str(xx),').bmp'];
AA = imread([name]);
% figure,imshow(AA), title('The real image');
g=AA(:,:,2); % image green componant
%g=medfilt2(green); %remove peper and salt noise with 3by3 median filter
p=0;
    for thr= 1:255
        p=p+1;
        rs= g > thr;
        [L num] = bwlabel(rs); 
        N(p)= num;
    end
%figure,plot(N),title('Green histogram')
x=find (N==max(N));
gg=g>x;     % intial segment value
% figure, imshow(gg), title('intial segmentation with Green histogram max ')
%#######################################
[L num] = bwlabel(gg);              
feature = regionprops(L,'Area');  %Computer Area of each region
area= [feature.Area];
x=[1:num];
[n,xout]=hist(area,x);   
figure,plot(xout,n), axis([0 100 0 500]), title('objects areas histogram')
fthr= 10; % This value depend on object area histogram 
%#######################################
for thr= 1:255
    gthr= g>thr;   
    [L num] = bwlabel(gthr);     %return matrix with connected pixel labeled         
    feature = regionprops(L,'Area');
    area= [feature.Area];
    maxarea= max(area);
    if maxarea < fthr;
         break
    end
end
gthr2=g>thr; %final threshold value
% figure,imshow(gthr2); title('Final threshold image')
figure,subplot(1,2,1), imshow(AA), title(name);
           subplot(1,2,2), imshow(gthr2), title('RBCs Mask  ') ;
%#######################################
x=1; y=1; supim=0;
for x=1:140:280
    for y=1:120:240
        supim=supim+1;
        Ac= imcrop(gthr,[y x 140 120]);
        Acr= imcrop(g,[y x 140 120]);
        [L num] = bwlabel(Ac);                
        no(supim)=num;        
        figure,subplot(1,2,2), imshow(Ac), title([' No. of RBCs=',int2str(no(supim))])
        subplot(1,2,1), imshow(Acr), title([name,'  Croped image']) 
%         Ac(:,:,supim)=Ac;
%         Acr(:,:,supim)=Acr;
    end
end

print('-f1',['A(',int2str(xx),')'],'-dpng');
print('-f2',['A(',int2str(xx),')Cut1'],'-dpng');
print('-f3',['A(',int2str(xx),')Cut2'],'-dpng');
print('-f4',['A(',int2str(xx),')Cut3'],'-dpng');
print('-f5',['A(',int2str(xx),')Cut4'],'-dpng');

delete(findall(0,'Type','figure'))

bdclose('all')


end


